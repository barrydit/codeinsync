<?php

echo "<h1>Hello, world! This project is public domain.</h1>";
