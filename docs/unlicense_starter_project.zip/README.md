# Unlicensed PHP Starter Project

This is a free and public domain PHP project licensed under the Unlicense.

## Features

- 100% public domain
- Easy to use
- No restrictions

## Getting Started

```bash
php -S localhost:8000
```

## License

This is free and unencumbered software released into the public domain.  
See the [UNLICENSE](UNLICENSE) file for more information.
